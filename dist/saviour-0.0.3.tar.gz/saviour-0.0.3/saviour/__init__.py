# -*- coding: utf-8 -*-
"""
Created on Sun Jul 26 02:25:13 2020

@author: Legedith
"""
from .style import styleme
from .euler_solution import eulersol
from .euler import euler_problem
from .switch_to_pseudo import pseudocode

